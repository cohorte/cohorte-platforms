Base repository
###############

This folder should contain application specifc bundles.
