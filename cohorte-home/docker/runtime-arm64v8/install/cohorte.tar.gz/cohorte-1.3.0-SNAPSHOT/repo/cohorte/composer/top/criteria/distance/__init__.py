#!/usr/bin/env python
# -- Content-Encoding: UTF-8 --
"""
Cohorte Composer factories distance criteria components

:author: Thomas Calmant
:license: Apache Software License 2.0
"""

# Documentation strings format
__docformat__ = "restructuredtext en"

# ------------------------------------------------------------------------------
