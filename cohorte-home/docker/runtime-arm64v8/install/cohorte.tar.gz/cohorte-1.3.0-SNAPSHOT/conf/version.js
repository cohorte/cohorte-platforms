{
	"distribution" : "cohorte-full-distribution",
	"stage" : "dev",
	"version" : "1.3.0",
	"timestamp" : "20171108-124752",
	"git_branch" : "master",
	"git_commit" : "6a9fc611903bca1fa90a1b1b3c47cb1424e6c572"
}
