{
	"distribution" : "cohorte-full-distribution",
	"stage" : "release",
	"version" : "1.3.2",
	"timestamp" : "20210113-151946",
	"git_branch" : "(HEAD",
	"git_commit" : "ae3c8545fa2d661814d585baac1f3b9a23769dab"
}
