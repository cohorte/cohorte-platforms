{
	"distribution" : "cohorte-full-distribution",
	"stage" : "release",
	"version" : "1.3.2",
	"timestamp" : "20210119-145959",
	"git_branch" : "(HEAD",
	"git_commit" : "e2d8c107ad7abd5f923b6d8098420ed2a158a745"
}
