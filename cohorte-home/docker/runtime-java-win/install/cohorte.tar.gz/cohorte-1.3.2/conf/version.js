{
	"distribution" : "cohorte-full-distribution",
	"stage" : "release",
	"version" : "1.3.2",
	"timestamp" : "20201204-133601",
	"git_branch" : "windowAndAlpine",
	"git_commit" : "0d946a157e7a257cc70335cce9fda028a52a3016"
}
