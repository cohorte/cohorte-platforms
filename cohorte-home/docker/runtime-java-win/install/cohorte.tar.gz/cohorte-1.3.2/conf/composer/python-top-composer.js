{
    "composition" : [
	    {
	        "factory" : "cohorte-composer-top-factory",
	        "name" : "cohorte-composer-top",
	        "properties" : {
	        	"autostart" : "${run:auto-start}",
	            "composition.filename" : "${run:composition-file}"
	        }
	    }
    ]
}
