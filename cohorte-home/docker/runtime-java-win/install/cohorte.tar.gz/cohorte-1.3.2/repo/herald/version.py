# Cohorte Herald
#
#
# History:
#
#
# Actual Version:

__version_info__ = (1, 0, 1)
__version__ = ".".join(str(x) for x in __version_info__)
__docformat__ = "restructuredtext en"