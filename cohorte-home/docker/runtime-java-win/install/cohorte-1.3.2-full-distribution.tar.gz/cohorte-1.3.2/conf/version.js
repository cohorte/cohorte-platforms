{
	"distribution" : "cohorte-full-distribution",
	"stage" : "release",
	"version" : "1.3.2",
	"timestamp" : "20201203-024508",
	"git_branch" : "(HEAD",
	"git_commit" : "d1bb50eb2ec53e5ae5dd9c2371342a0b2128bc8f"
}
